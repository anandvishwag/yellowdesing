import React, {useState, useEffect} from 'react'
import styles from '../../styles/Header.module.scss'
import Link from 'next/link'
import { FaWhatsapp, FaFacebookF, FaInstagram } from "react-icons/fa";
const Header = () => {
  const [sticky, setSticky] = useState("");
  const [showMenu, setToggleMenu] = useState(false);
 // on render, set listener
 useEffect(() => {
  window.addEventListener("scroll", isSticky);
  return () => {
      window.removeEventListener("scroll", isSticky);
  };
}, []);

const isSticky = () => {
  const scrollTop = window.scrollY;
  const stickyClass = scrollTop >= 150;
  setSticky(stickyClass);
};
  return (
    <header className={`${styles.headerWrapper} ${sticky ? styles.headerSticky : ''}`}>
      <div className={`container ${styles.headerContainer}`}>
        <div className={styles.brand}>
          <img src='/images/logo.png' alt='brand'/>
        </div>
        <div className={styles.headerRight}>
           <div className={styles.headerTop}>
              <div className={styles.whatsapp}>
             <FaWhatsapp color='#23AC44' size={25}/>  <span>+91 - 9696475344</span>
              </div>
              <div className={styles.followUs}>
                  <span>Follow Us</span>
                  <ul>
                      <li><Link href={'/'}><a><FaFacebookF  color='#7A5E27' size={20}/></a></Link></li>
                      <li><Link href={'/'}><a><FaInstagram  color='#7A5E27' size={20}/></a></Link></li>
                  </ul>
              </div>
           </div>
           <div className={`${styles.navigation} ${showMenu ? `${styles.showMenu}` : ``}`}>
             <ul>
                <li><Link href={'/'}><a>Home</a></Link></li>
                <li><Link href={'/about'}><a>About</a></Link></li>
                <li><Link href={'/'}><a>Services</a></Link></li>
                <li><Link href={'/building-material-enquiry-form'}><a>Enquiry</a></Link></li>
                <li><Link href={'/contact-us'}><a>Contact</a></Link></li>
             </ul>

            
           </div>
           <button className={`${styles.toggleButton} ${showMenu ? `${styles.showMenuButton}` : ``}`} onClick={()=>setToggleMenu(!showMenu)}>
                 <span></span>
                 <span></span>
                 <span></span>
             </button>
        </div>
      </div>
    </header>
  )
}

export default Header