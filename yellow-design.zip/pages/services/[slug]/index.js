import React, { Fragment, useEffect, useState } from 'react'
import InnerPageBanner from '../../../components/partials/InnerPageBanner'
import styles from '../../../styles/InnerPage.module.scss'
import { FiChevronRight } from "react-icons/fi";
import Accordion from 'react-bootstrap/Accordion';
import Link from 'next/link'
const SingleService = () => {
    let bannerImage = '/images/innerBnr.jpg';

  return (
   <Fragment>
      <InnerPageBanner pageTitle={'Planing'} bannerImage={bannerImage} style={styles}/>
      <div className={styles.innerPageWrapper}>
        <div className='container'>
            <div className='row'>
                <div className='col-md-9'>
                    <div className={styles.serviceFeatured}>
                        <img src='/images/services/planing.jpg' alt='featured image'/>
                    </div>
                    <div className={styles.serviceDetails}>
                        <h4 className={styles.subTitle}>About Planning Service in Yellow Wood Design & Constructions</h4>
                        <h1 className={styles.title}>We offer the best planning service</h1>
                       <p> Planning architecture involves designing and organizing spaces to meet specific needs, whether it's for residential, commercial, or public purposes. It encompasses understanding client requirements, considering site constraints, adhering to building codes and regulations, and creating aesthetically pleasing and functional designs. From conceptual sketches to detailed blueprints, architects blend creativity with technical expertise to bring structures to life. They also often collaborate with engineers, contractors, and other professionals to ensure projects are executed smoothly and successfully. Architecture isn't just about creating buildings; it's about shaping environments and improving the way people interact with their surroundings.</p>

                       <p>Architects work closely with clients to understand their needs, goals, and budget for the project. This stage involves gathering information about spatial requirements, functional needs, and any specific preferences or constraints.</p>

                       <p>Before designing a building, architects thoroughly analyze the site where it will be located. Factors such as topography, climate, vegetation, neighboring structures, and legal restrictions all influence the design process.</p>

                       <p>This is where creativity flourishes. Architects develop initial design concepts that address the client's requirements while considering the site context. Sketches, diagrams, and 3D models are often used to communicate these ideas.</p>
                    </div>
                </div>
                <div className='col-md-3'>
                    <div className={styles.serviceWidget}>
                        <h2 className={styles.widgetTitle}>Our Services</h2>
                        <div className={styles.widgetContent}>
                            <ul>
                                <li>
                                    <Link href="/"><a><span>Planning</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>2D Design</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>3D Elevation</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>Interior Designing</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>Vaastu Consultation</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>Structural Designing</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>Waterproofing</span> <FiChevronRight /></a></Link>
                                    <Link href="/"><a><span>Material Provider</span> <FiChevronRight /></a></Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className={styles.serviceWidget}>
                        <h2 className={styles.widgetTitle}>Opening Hours</h2>
                        <div className={styles.widgetContent}>
                            <ul>
                                <li>
                                    <Link href="/"><a><span>Monday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Tuesday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Wednessday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Thursday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Friday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Saturday</span> 9 AM - 6 PM</a></Link>
                                    <Link href="/"><a><span>Sunday</span> OFF</a></Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className={styles.ourProductS}>
                <h1>Our Project</h1>
                <div className='row'>
                    <div className='col-md-4'>
                        <img src='/images/services/service-1.png' alt='projects'/>
                    </div>
                    <div className='col-md-4'>
                        <img src='/images/services/service-2.png' alt='projects'/>
                    </div>
                    <div className='col-md-4'>
                        <img src='/images/services/service-3.png' alt='projects'/>
                    </div>
                </div>
            </div>
            <div className={styles.faqs}>
                <h1 className={styles.faqTitle}>Faqs</h1>
                <Accordion defaultActiveKey="0">
      <Accordion.Item eventKey="0">
        <Accordion.Header>1 - What is the role of an architect in planning architecture?</Accordion.Header>
        <Accordion.Body>
        Architects design and organize spaces, ensuring they meet client needs, adhere to regulations, and blend creativity with functionality.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
        <Accordion.Header>2 - How long does it typically take to complete the architectural planning process for a building?</Accordion.Header>
        <Accordion.Body>
        The timeline varies depending on the project's complexity and scope, but it can range from several months to several years from initial concept to completion.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="2">
        <Accordion.Header>3 - What software do architects use for planning architecture?</Accordion.Header>
        <Accordion.Body>
        Architects commonly use software such as AutoCAD, Revit, SketchUp, and Adobe Creative Suite for drafting, modeling, and visualization during the architectural planning process.
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="3">
        <Accordion.Header>4 - How do architects ensure their designs are environmentally friendly?</Accordion.Header>
        <Accordion.Body>
        Architects incorporate sustainable design principles such as energy efficiency, use of renewable materials, and consideration of site orientation and natural ventilation to minimize environmental impact in their designs.
        </Accordion.Body>
      </Accordion.Item>
    
    </Accordion>
            </div>
        </div>
         
      </div>
   </Fragment>
  )
}
SingleService.layout = 'Main'
export default SingleService;